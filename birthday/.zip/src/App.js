
import './App.css';
import BirthDay from './components/BirthDay';

function App() {
  return <BirthDay />
}

export default App;
