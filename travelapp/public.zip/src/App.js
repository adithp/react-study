
import './App.css';
import TravelApp from './components/screens/TravelApp';

function App() {
  return (
  <TravelApp />
    );
}

export default App;
